﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SelfOrganizingNetworks
{
    class SelfOrganizingTaskV1 : SelfOrganizingTaskV0
    {

        public SelfOrganizingTaskV1()
        {
            NetworkWidth = 5;
            NetworkHeight = 5;
        }
        
    }
}
